/* <script.js>
Copyright (c) 2022 C-DAC Pune
Sarita Kumari Singh <saritas@cdac.in>
v0.0.4 18-July-2022
(Conversion of Text File to HTML file using javascript along with HTML and CSS)
 */

const x = document.querySelector('input');
x.addEventListener('change', () => {
  const fr = new FileReader();
  fr.onloadend = (e) => {
    let r = fr.result.split(/\n[^\t]/).map((e) => {
      return e.split('/^(?!s*$).+/g');
    });
    console.log(r);
    r.forEach((e) => {
      let m = e
        .map((e, i) => {
          const array = new Array();

          
          let res = e.match(/(v\d{1,4}([.])\d{1,2}([.])\d{1,4})/g);
          let res1 = e.match(/[a-zA-Z]{3}[-][0-9]{4}/g);
          let res4 = e.match(
            /\t[ a-zA-Z0-9!@#$%^&()_+\-=\[\]{};':"\\|,.<>\/?]*/g
          );
		  
       
          let n = res4.map((e, i) => {
            if (e.includes('\t- ')) {
              let s = e.split('\t- ').join(' ');
              return `<ul><li>${s}</li></ul>`;
            }
            else {
              let s = e.split('\t- ').join('  ');
              return s;
            }
          });
       
        function createCustomObj( res, res1,n){
          var obj={};
          
              res1.forEach( function(f, i){
                  obj[f]={};
              obj[f]['a']= res[i];
              obj[f]['b']= res1[i];
              obj[f]['c']= n;
              
          });
          return obj;
          };
         const newObj=createCustomObj(res1,res,res4);
      for (let val in newObj){
        // console.log(val);
        let uniq = val => [...new Set(val)];
         console.log(newObj[val]);
      }
//       const entries = Object.entries(newObj);
// const result=newObj.reduce((finalArray,current)=>{
//   let obj=finalArray.find((item)=>item.id==current.id);
//   if(obj){
//     return finalArray;
//   }
//   return finalArray.concat([current])

// },[]);
// console.log(finalArray);

// console.log(uniqueObjectArray);
          array.push(
            `<td id="ver">${res1}</td>`,
            `<td id=
                "date">${res}</td>`,
            `<td id="desc">${n}</td>`
          );
          e = array.join('');
          e = e.replace(/,/g, '');
          return `<td >${e}</td>`;
        })
        .join(' ');
      const ce = document.createElement('tr');
      ce.innerHTML = m;
      if (ce.innerText !== '') {
        document.querySelector('table').append(ce);
      }
    });
  };
  fr.readAsText(x.files[0]);
});